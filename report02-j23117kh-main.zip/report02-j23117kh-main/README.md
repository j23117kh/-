[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/XuCLEXKr)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=22021694&assignment_repo_type=AssignmentRepo)
# レポート課題 II：CRUD 完成アプリ（FastAPI × SQLite × Vue）

東京情報大学 情報システム学系
システムプログラミング（2025後期）

---

## 🎯 課題概要

第7〜9回で構築した **FastAPI（SQLite 永続化）＋ Vue（CLI）** を組み合わせ、
**一覧 → 詳細 → 更新 → 削除** が動作する **CRUDアプリ**を完成させる。

レポート課題 II では、
**「API・DB付きの最小フルスタックアプリ」** を作り上げることが目標。

---

## 🧩 やること

1. 自分のテーマ（例：タスク管理、読書ログ、費用トラッカー等）を1つ選択
2. バックエンド：

   * FastAPI＋SQLite（SQLAlchemy）で
     **GET /items, POST /items, GET/PUT/DELETE /items/{id}** を実装
3. フロントエンド：

   * Vue（CLI）で
     **一覧（ItemsPage.vue）＋詳細（ItemDetail.vue）** の2画面構成
4. CRUD 完成

   * 一覧：表示＋新規追加
   * 詳細：IDごとの表示＋更新＋削除
5. 保存戦略は **SQLite（RDB）** に固定
6. UI操作時の挙動（エラー表示・disabled制御など）を整える

---

## 📦 提出物

| 項目       | 内容                                                     |
| -------- | ------------------------------------------------------ |
| プログラムコード | `api-demo/`（Vue）＋ `fastapi-app/`（FastAPI）一式            |
| 仕様書      | `doc/report2.md` に記載（目的／機能一覧／画面構成／API仕様／保存戦略／既知の問題 など） |
| README   | （このファイル）課題説明用。最終成果物としてリポジトリに含める                        |

---

## 🗂️ 推奨ディレクトリ構成

```
（個人リポジトリ）
├─ api-demo/            # Vue
│   ├─ src/
│   │   ├─ api/api.js
│   │   ├─ router/index.js
│   │   └─ components/
│   │       ├─ ItemsPage.vue
│   │       └─ ItemDetail.vue
│   └─ package.json
│
├─ fastapi-app/         # FastAPI（SQLite永続化）
│   ├─ db.py
│   ├─ main.py
│   ├─ models/item.py
│   ├─ schemas/item.py
│   └─ crud/item.py
│
└─ doc/
    └─ report2.md       # 仕様書
README.md
```

---

## 🚀 提出方法

1. GitHub Classroom の個人リポジトリを clone
2. FastAPI（backend）と Vue（frontend）を作成
3. 動作確認

   * `npm run serve`（8080）
   * `uvicorn main:app --reload --port 8000`
4. 仕様書を `doc/report2.md` に記載
5. コミット＆プッシュ（mainブランチ）

> ※ 自動採点はありませんが、**授業内レビュー（第12回）で確認されます**。

---

## 🔍 動作要件チェック（自己チェック欄）

### ◎ 一覧（ItemsPage.vue）

* [ ] GET /items で一覧取得
* [ ] 新規追加（POST /items）後、一覧が更新される
* [ ] 各行タイトルをクリックすると `/items/:id` へ遷移する

### ◎ 詳細（ItemDetail.vue）

* [ ] GET /items/:id で個別データ取得
* [ ] 更新（PUT /items/:id）が正しく反映される
* [ ] 削除（DELETE /items/:id）後、一覧ページに戻る
* [ ] エラーメッセージ（404/422）が画面で確認できる

### ◎ API（FastAPI + SQLite）

* [ ] CORS 設定に `http://localhost:8080` が含まれる
* [ ] Pydantic と Model の整合性が取れている
* [ ] DBファイル（items.db）が永続化される（再起動しても残る）

---

## 🧮 採点の目安（100点満点 ※調整あり）

| 評価観点   | 内容                      | 配点  |
| ------ | ----------------------- | --- |
| CRUD動作 | 一覧／追加／詳細／更新／削除が揃っている    | 30点 |
| DB永続化  | SQLite＋SQLAlchemyの正しい構成 | 20点 |
| 画面遷移   | `/items/:id` の実装、UIの自然さ | 15点 |
| コード品質  | ファイル分割、命名、見通し、再利用性      | 15点 |
| 仕様書    | report2.md の記述内容        | 20点 |

---

## 📘 注意事項（重要）

* 保存方式は **SQLite（RDB）固定**

  * MongoDB は課題 III で使用（任意）
* API_URL が **3000（json-server）** のままになっていないか注意
* エラーハンドリング（404/422）を正しく実装する
* **提出期限：2026年1月4日（日）23:59**
* 締切後の更新は減点対象

---

## 🔧 起動手順（まとめ）

### ◎ バックエンド（FastAPI／8000）

```
cd fastapi-app
uvicorn main:app --reload --port 8000
```

### ◎ フロントエンド（Vue／8080）

```
cd api-demo
npm run serve
```

### ◎ ブラウザ

```
http://localhost:8080/
```

---

